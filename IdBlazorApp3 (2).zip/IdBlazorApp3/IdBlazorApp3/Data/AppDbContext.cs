﻿using Microsoft.EntityFrameworkCore;

namespace IdBlazorApp3.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Message> Messages { get; set; }
    }

    public class Message
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public string MessageContent { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDate { get; set; }
        public string Status { get; set; }
    }
}
