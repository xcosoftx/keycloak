﻿namespace IdBlazorApp3.Data
{
    public interface IItemProvider
    {
        Task<List<string>> GetItems(int startIndex, int count);
    }

}
