﻿namespace IdBlazorApp3.Data
{
    public class MyItemProvider : IItemProvider
    {
        public async Task<List<string>> GetItems(int startIndex, int count)
        {
            // Implement logic to fetch items dynamically
            // Example: fetch items from a database or web service
            List<string> items = new List<string>();

            for (int i = startIndex; i < startIndex + count; i++)
            {
                items.Add($"Item {i}");
            }

            await Task.Delay(100); // Simulate async delay

            return items;
        }
    }

}
