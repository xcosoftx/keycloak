﻿// wwwroot/virtualize.js

window.getElementInfo = (element) => {
    if (!element) {
        return null;
    }

    return {
        top: element.getBoundingClientRect().top,
        clientHeight: element.clientHeight
    };
};
